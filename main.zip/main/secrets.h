#include "esp_wifi.h"

// wifi_sta_config_t wConf;
// wConf.ssid = *ssid;

// wifi_config_t sta_config = {wConf}

// wifi_config_t sta_config = {
//     .sta.ssid      = *ssid,
//     .sta.password  = *password,
//     .sta.bssid_set = false};



// wifi_config_t sta_config = {
//     .sta = {
//         .ssid      = "variablesnet",
//         .password  = "letmeinplease",
//         .bssid_set = false}};


// extern "C" {

// wifi_config_t sta_config = {
//     // .ap  = {},
//     .sta = {
//         .ssid            = "variablesnet",
//         .password        = "letmeinplease",
//         .scan_method     = WIFI_FAST_SCAN,
//         .bssid_set       = false,
//         .bssid           = "",                        /**< MAC address of target AP*/
//         .channel         = 0,                         /**< channel of target AP. Set to 1~13 to scan starting from the specified channel before connecting to AP. If the channel of AP is unknown, set it to 0.*/
//         .listen_interval = 0,                         /**< Listen interval for ESP32 station to receive beacon when WIFI_PS_MAX_MODEM is set. Units: AP beacon intervals. Defaults to 3 if set to 0. */
//         .sort_method     = WIFI_CONNECT_AP_BY_SIGNAL, /**< sort the connect AP in the list by rssi or security mode */
//         .threshold       = {
//             .rssi     = 0,
//             .authmode = WIFI_AUTH_WPA2_PSK} /**< When scan_method is set to WIFI_FAST_SCAN, only APs which have an auth mode that is more secure than the selected auth mode and a signal stronger than the minimum RSSI will be used. */
//     }};
// }

// 	wifi_sta_config_t wc = 
//     {
//         "variablesnet",
//         "letmeinplease",
//         .scan_method     = WIFI_FAST_SCAN,
//         .bssid_set       = false,
//         "",                        /**< MAC address of target AP*/
//         0,                         /**< channel of target AP. Set to 1~13 to scan starting from the specified channel before connecting to AP. If the channel of AP is unknown, set it to 0.*/
//         .listen_interval = 0,                         /**< Listen interval for ESP32 station to receive beacon when WIFI_PS_MAX_MODEM is set. Units: AP beacon intervals. Defaults to 3 if set to 0. */
//         .sort_method     = WIFI_CONNECT_AP_BY_SIGNAL, /**< sort the connect AP in the list by rssi or security mode */
//         {
//             0,
//             WIFI_AUTH_WPA2_PSK} /**< When scan_method is set to WIFI_FAST_SCAN, only APs which have an auth mode that is more secure than the selected auth mode and a signal stronger than the minimum RSSI will be used. */
//     };

// wifi_config_t sta_config = wc;