#ifdef __cplusplus
extern "C" {
#endif
#ifndef HELPER_H
#define HELPER_H

#include <sys/time.h>
#include "esp_types.h"


// #include <stdio.h>
// #include <stdlib.h>
// #include <sys/types.h>

uint64_t millis();


#endif
#ifdef __cplusplus
}
#endif